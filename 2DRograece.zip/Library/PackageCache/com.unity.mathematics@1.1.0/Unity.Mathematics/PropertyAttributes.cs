﻿namespace Unity.Mathematics
{
    public class PostNormalizeAttribute : UnityEngine.PropertyAttribute {}

    public class DoNotNormalizeAttribute : UnityEngine.PropertyAttribute {}
}