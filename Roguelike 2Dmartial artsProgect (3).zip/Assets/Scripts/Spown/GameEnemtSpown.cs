using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameEnemtSpown : MonoBehaviour
{
    public Transform SpownPos;
    public GameObject spownEnemy;
    // Start is called before the first frame update
    void Start()
    {
        
    }

}
