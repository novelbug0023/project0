using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFlow2D : MonoBehaviour
{
    public Transform CameTarget;
    Vector2 playerPOS;
    Vector3 thisCaemraPos;
    public Camera minmapCamera;
    public float CameraSpeed;
    public float JumpCameraSpeed = 20f;
    public LayerMask ground;
    bool isjump;
    // Start is called before the first frame update
    void Start()
    {
        CameTarget = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        playerPOS = CameTarget.position;
    }

    // Update is called once per frame
    void Update()
    {
        #region �ȵ� �κ�
        //this.transform.LookAt(CameTarget);
        //this.transform.Translate(CameTarget.position);
        #endregion
        float delta = CameraSpeed * Time.deltaTime;
        #region �ȵ� �κ�
        //Vector3 dir = CameTarget.transform.position - this.transform.position;
        //Vector3 moveVector = new Vector3(dir.x /** delta*/, dir.y + 2/* * CameraSpeed * Time.deltaTime, 0.0f*/);
        //this.transform.position = new Vector3(moveVector.x, 0.0f, this.transform.position.z);
        #endregion
        Camera.main.transform.position = Vector3.Lerp(Camera.main.transform.position, new Vector3(CameTarget.transform.position.x, this.transform.position.y, this.transform.position.z),delta);
        #region �ȵ� �κ�
        //new Vector3(CameTarget.transform.position.x, 0.0f, this.transform.position.z);
        
        //�������� ab�� ����
        //this.transform.Translate(moveVector);
        
        //if (CameTarget.transform.localPosition.y > 3.0f)
        //{
        //    this.transform.position = new Vector3(this.transform.position.x, (CameTarget.transform.position.y - 3.0f)+4.5f, -9.39f);
        //}
        //else if (CameTarget.transform.localPosition.y < -0.88f)
        //{
        //    this.transform.position = new Vector3(this.transform.position.x, CameTarget.transform.position.y - 1.01f+2, -9.39f);
        //}
        #endregion
        if (this.transform.position.x < -48.19f)
        {
            this.transform.position = new Vector3(-48.19f, this.transform.position.y, this.transform.position.z);
        }
        if (this.transform.position.x > -1.8f)
        {
            this.transform.position = new Vector3(-1.8f, this.transform.position.y, this.transform.position.z);
        }
        if (minmapCamera.transform.position.x < -24.9f)
        {
            minmapCamera.transform.position = new Vector3(-24.9f, minmapCamera.transform.position.y, minmapCamera.transform.position.z);
        }
        if (minmapCamera.transform.position.x > 14.1f)
        {
            minmapCamera.transform.position = new Vector3(14.1f, minmapCamera.transform.position.y, minmapCamera.transform.position.z);
        }
        //thisCaemraPos = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);

        #region ī�޶� ���Ʒ� �̵� �ȵȺκ�
        //if (CameTarget.transform.position.y > this.transform.localPosition.y)
        //{
        //    Camera.main.transform.position = Vector3.Lerp(Camera.main.transform.position, new Vector3(CameTarget.transform.position.x, CameTarget.transform.position.y +3f, this.transform.position.z), delta);
        //}
        //if (CameTarget.transform.position.y < this.transform.localPosition.y)
        //{
        //    Camera.main.transform.position = Vector3.Lerp(Camera.main.transform.position, new Vector3(CameTarget.transform.position.x, CameTarget.transform.position.y+3f, this.transform.position.z), delta);
        //}
        //if (CameTarget.transform.position.y == this.transform.localPosition.y)
        //{
        //    return;
        //    //Camera.main.transform.position = Vector3.Lerp(Camera.main.transform.position, new Vector3(CameTarget.transform.position.x, CameTarget.transform.position.y, this.transform.position.z), delta);
        //}
        #endregion
        jumpCamera();
    }
    void jumpCamera()
    {
        float delta = JumpCameraSpeed * Time.smoothDeltaTime;
        Ray2D ray = new Ray2D(CameTarget.position, Vector2.down);
        RaycastHit2D hit = Physics2D.Raycast(ray.origin, ray.direction, 1000.0f, ground);
        Debug.DrawRay(CameTarget.position, Vector2.down, Color.green);
        Vector2 player = CameTarget.position;
        Vector2 camerapos = this.transform.position;
        float dist = Vector2.Distance(player, new Vector2(hit.point.x, hit.point.y + 3.0f));
        Debug.Log(string.Format("Player : {0}, hit.point : {1}", player, hit.point));
        if (dist > 3.0f)
        {
            Camera.main.transform.position = Vector3.Slerp(Camera.main.transform.position, new Vector3(CameTarget.transform.position.x, CameTarget.transform.position.y, this.transform.position.z), delta);
        }
        if (dist <= 1.0f)
        {
            Debug.Log("S");
            this.transform.position = new Vector3(CameTarget.transform.position.x, CameTarget.transform.position.y, this.transform.position.z);
            //if (hit.collider == null)
            //{
            //    if (isjump == true)
            //    {
            //        //this.transform.position = new Vector3(CameTarget.transform.position.x, CameTarget.transform.position.y + 3f, this.transform.position.z);
            //        isjump = false;
            //        return;
            //    }
            //    else
            //    {
            //        return;
            //    }
            //}
            //else
            //{
            //    if (isjump != true)
            //    {
            //        this.transform.position = new Vector3(CameTarget.transform.position.x, CameTarget.transform.position.y + 3f, this.transform.position.z);
            //    }
            //    isjump = true;
            //}


        }
    }
}
