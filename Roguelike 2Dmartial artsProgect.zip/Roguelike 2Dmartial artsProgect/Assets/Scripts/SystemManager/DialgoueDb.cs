using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class DialgoueDb : MonoBehaviour
{
    public string[] story;
    //#region �̱���
    //private static DialgoueDb instance = null;
    //void Awake()
    //{
    //    if (null == instance)
    //    {
    //        instance = this;

    //        DontDestroyOnLoad(this.gameObject);
    //    }
    //    else
    //    {
    //        Destroy(this.gameObject);
    //    }
    //}

    //public static DialgoueDb Instance
    //{
    //    get
    //    {
    //        if (null == instance)
    //        {
    //            return null;
    //        }
    //        return instance;
    //    }
    //}


    //#endregion
}
