using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyManager : MonoBehaviour
{
    public SpwonEnemy Spwonenemy;
    public int hp = 100;
    public int Maxhp = 100;
    public int AttackPoint;
    public Image hpBar;
    //#region �̱���
    //private static EnemyManager instance = null;
    //public static EnemyManager Instance
    //{
    //    get
    //    {
    //        if (null == instance)
    //        {
    //            return null;
    //        }
    //        return instance;
    //    }
    //}
    //#endregion
    // Start is called before the first frame update
    void Start()
    {
        Spwonenemy = GameObject.FindGameObjectWithTag("MapDB").GetComponent<SpwonEnemy>();
    }

    // Update is called once per frame
    void Update()
    {
        if (hp <= 0)
        {
            Destroy(this.gameObject);
            Spwonenemy.DB.mapEnemy.Remove(this.gameObject);
        }
    }
}
